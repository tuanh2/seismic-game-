import React, { useRef, useEffect, useCallback } from 'react';
import type { GameState, Vector, Player, Boss, Projectile, Collectible, GameStatus } from '../types';
import { GameStatus as GameStatusEnum } from '../types';
import {
  CANVAS_WIDTH, CANVAS_HEIGHT, PLAYER_MAX_HEALTH, PLAYER_RADIUS,
  PLAYER_SHOOT_COOLDOWN, PLAYER_PROJECTILE_RADIUS, PLAYER_PROJECTILE_SPEED,
  PLAYER_PROJECTILE_DAMAGE, LEVEL_CONFIGS, PLAYER_IMAGE_B64,
  COLLECTIBLE_IMAGE_B64, COLLECTIBLE_BASE_VALUE, COLLECTIBLE_BASE_RADIUS,
  CHEAT_SECRET, SHOOT_SOUND_B64, COLLECT_SOUND_B64, HIT_SOUND_B64
} from '../constants';
import { initAudio, playSound, loadSounds } from '../utils/audio';

interface GameCanvasProps {
  gameStatus: GameStatus;
  onGameOver: (finalState: GameState) => void;
  onStateUpdate: (newState: GameState) => void;
  onPause: () => void;
  onRestart: () => void;
}

const GameCanvas: React.FC<GameCanvasProps> = ({ gameStatus, onGameOver, onStateUpdate, onPause, onRestart }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameState = useRef<GameState | null>(null);
  const lastTime = useRef<number>(0);
  const lastPlayerShootTime = useRef<number>(0);
  const activeBossPatterns = useRef<{ type: string; timeLeft: number; internalCooldown: number; fireRateTimer: number; angle?: number }[]>([]);

  const playerImage = useRef<HTMLImageElement>(new Image());
  const collectibleImage = useRef<HTMLImageElement>(new Image());

  useEffect(() => {
    playerImage.current.src = PLAYER_IMAGE_B64;
    collectibleImage.current.src = COLLECTIBLE_IMAGE_B64;
    loadSounds({
      shoot: SHOOT_SOUND_B64,
      collect: COLLECT_SOUND_B64,
      hit: HIT_SOUND_B64,
    });
  }, []);
  
  const calculateChecksum = (score: number, level: number): string => {
    return btoa(`${score}:${level}:${CHEAT_SECRET}`);
  };

  const initLevel = useCallback((level: number, oldState?: GameState) => {
    const config = LEVEL_CONFIGS[level - 1];
    if (!config) {
        // WIN CONDITION
        onGameOver(gameState.current!);
        return;
    }

    const newPlayer: Player = oldState ? oldState.player : {
      pos: { x: CANVAS_WIDTH / 4, y: CANVAS_HEIGHT / 2 },
      radius: PLAYER_RADIUS,
      health: PLAYER_MAX_HEALTH,
      maxHealth: PLAYER_MAX_HEALTH,
    };
    if(oldState) newPlayer.health = Math.min(PLAYER_MAX_HEALTH, newPlayer.health + 25); // Heal between levels

    const newBoss: Boss = {
        pos: { x: CANVAS_WIDTH * 0.8, y: CANVAS_HEIGHT / 2 },
        radius: config.bossRadius,
        health: config.bossHealth,
        maxHealth: config.bossHealth,
        phase: 0,
        patternCooldown: 2000,
    };
    
    const newCollectibles: Collectible[] = [];
    for(let i = 0; i < config.collectibleCount; i++) {
        const sizeMultiplier = Math.random() * 1.5 + 0.5;
        newCollectibles.push({
            pos: { x: Math.random() * CANVAS_WIDTH, y: Math.random() * CANVAS_HEIGHT },
            radius: COLLECTIBLE_BASE_RADIUS * sizeMultiplier,
            value: Math.floor(COLLECTIBLE_BASE_VALUE * sizeMultiplier),
            velocity: { x: (Math.random() - 0.5) * 2, y: (Math.random() - 0.5) * 2 }
        });
    }

    gameState.current = {
      player: newPlayer,
      boss: newBoss,
      playerProjectiles: [],
      bossProjectiles: [],
      collectibles: newCollectibles,
      score: oldState ? oldState.score : 0,
      level,
      mousePos: oldState ? oldState.mousePos : { x: 0, y: 0 },
      isShooting: oldState ? oldState.isShooting : false,
      gameTime: oldState ? oldState.gameTime : 0,
      screenShake: 0,
      checksum: calculateChecksum(oldState ? oldState.score : 0, level),
    };
    activeBossPatterns.current = [];
  }, [onGameOver]);
  
  useEffect(() => {
    if (gameStatus === GameStatusEnum.Playing && !gameState.current) {
        initLevel(1);
    }
    if (gameStatus === GameStatusEnum.StartScreen) {
        gameState.current = null;
    }
  }, [gameStatus, initLevel, onRestart]);

  const gameLoop = useCallback((timestamp: number) => {
    if (gameStatus !== GameStatusEnum.Playing || !gameState.current) {
      lastTime.current = timestamp;
      requestAnimationFrame(gameLoop);
      return;
    }
    
    const deltaTime = timestamp - lastTime.current;
    lastTime.current = timestamp;

    const state = gameState.current;
    
    // UPDATE LOGIC
    state.gameTime += deltaTime;

    // Player movement
    const dx = state.mousePos.x - state.player.pos.x;
    const dy = state.mousePos.y - state.player.pos.y;
    const dist = Math.sqrt(dx * dx + dy * dy);
    if(dist > 1) {
        const speed = 0.3;
        state.player.pos.x += (dx / dist) * Math.min(dist, speed * deltaTime);
        state.player.pos.y += (dy / dist) * Math.min(dist, speed * deltaTime);
    }

    // Player shooting
    if (state.isShooting && timestamp - lastPlayerShootTime.current > PLAYER_SHOOT_COOLDOWN) {
      lastPlayerShootTime.current = timestamp;
      const angle = Math.atan2(state.boss.pos.y - state.player.pos.y, state.boss.pos.x - state.player.pos.x);
      state.playerProjectiles.push({
        pos: { ...state.player.pos },
        radius: PLAYER_PROJECTILE_RADIUS,
        velocity: {
          x: Math.cos(angle) * PLAYER_PROJECTILE_SPEED,
          y: Math.sin(angle) * PLAYER_PROJECTILE_SPEED,
        },
        damage: PLAYER_PROJECTILE_DAMAGE,
      });
      playSound('shoot', 0.2);
    }

    // Boss AI
    state.boss.patternCooldown -= deltaTime;
    if (state.boss.patternCooldown <= 0) {
        const config = LEVEL_CONFIGS[state.level - 1];
        const pattern = config.patterns[Math.floor(Math.random() * config.patterns.length)];
        activeBossPatterns.current.push({ type: pattern.type, timeLeft: pattern.duration, internalCooldown: pattern.cooldown, fireRateTimer: 0, angle: pattern.angle || 0 });
        state.boss.patternCooldown = 2000 + Math.random() * 2000;
    }

    // Process active patterns
    activeBossPatterns.current.forEach(p => {
        p.timeLeft -= deltaTime;
        p.fireRateTimer -= deltaTime;

        const configPattern = LEVEL_CONFIGS[state.level-1].patterns.find(cp => cp.type === p.type)!;

        if (p.fireRateTimer <= 0) {
            p.fireRateTimer = 1000 / configPattern.fireRate!;
            
            switch (p.type) {
                case 'burst':
                    for (let i = 0; i < configPattern.projectileCount!; i++) {
                        const angle = (i / configPattern.projectileCount!) * 2 * Math.PI;
                        state.bossProjectiles.push({ pos: { ...state.boss.pos }, radius: 8, velocity: { x: Math.cos(angle) * configPattern.projectileSpeed, y: Math.sin(angle) * configPattern.projectileSpeed }, damage: 10 });
                    }
                    break;
                case 'spiral':
                    const spiralAngle = state.gameTime * 0.005 + p.angle!;
                    state.bossProjectiles.push({ pos: { ...state.boss.pos }, radius: 6, velocity: { x: Math.cos(spiralAngle) * configPattern.projectileSpeed, y: Math.sin(spiralAngle) * configPattern.projectileSpeed }, damage: 5, rotation: 0 });
                    break;
                case 'targeted':
                    const targetAngle = Math.atan2(state.player.pos.y - state.boss.pos.y, state.player.pos.x - state.boss.pos.x);
                    state.bossProjectiles.push({ pos: { ...state.boss.pos }, radius: 7, velocity: { x: Math.cos(targetAngle) * configPattern.projectileSpeed, y: Math.sin(targetAngle) * configPattern.projectileSpeed }, damage: 8 });
                    break;
                case 'wave':
                    for (let i = 0; i < configPattern.projectileCount!; i++) {
                        const yPos = (i / configPattern.projectileCount!) * CANVAS_HEIGHT;
                        state.bossProjectiles.push({ pos: { x: CANVAS_WIDTH - state.boss.radius, y: yPos }, radius: 10, velocity: { x: -configPattern.projectileSpeed, y: 0 }, damage: 15 });
                    }
                    break;
            }
        }
    });
    activeBossPatterns.current = activeBossPatterns.current.filter(p => p.timeLeft > 0);


    // Update projectiles
    state.playerProjectiles.forEach(p => { p.pos.x += p.velocity.x; p.pos.y += p.velocity.y; });
    state.bossProjectiles.forEach(p => { p.pos.x += p.velocity.x; p.pos.y += p.velocity.y; });

    // Update collectibles
    state.collectibles.forEach(c => {
        c.pos.x += c.velocity.x;
        c.pos.y += c.velocity.y;
        if(c.pos.x < 0 || c.pos.x > CANVAS_WIDTH) c.velocity.x *= -1;
        if(c.pos.y < 0 || c.pos.y > CANVAS_HEIGHT) c.velocity.y *= -1;
    });

    // Collision detection
    // Player projectiles vs Boss
    state.playerProjectiles = state.playerProjectiles.filter(p => {
        const dist = Math.hypot(p.pos.x - state.boss.pos.x, p.pos.y - state.boss.pos.y);
        if (dist < p.radius + state.boss.radius) {
            state.boss.health -= p.damage;
            state.score += 10;
            state.screenShake = 5;
            return false;
        }
        return true;
    });

    // Boss projectiles vs Player
    state.bossProjectiles = state.bossProjectiles.filter(p => {
        const dist = Math.hypot(p.pos.x - state.player.pos.x, p.pos.y - state.player.pos.y);
        if (dist < p.radius + state.player.radius) {
            state.player.health -= p.damage;
            state.screenShake = 15;
            playSound('hit', 0.5);
            return false;
        }
        return true;
    });

    // Player vs Collectibles
    state.collectibles = state.collectibles.filter(c => {
        const dist = Math.hypot(c.pos.x - state.player.pos.x, c.pos.y - state.player.pos.y);
        if (dist < c.radius + state.player.radius) {
            state.score += c.value;
            playSound('collect', 0.3);
            return false;
        }
        return true;
    });

    // Cleanup off-screen projectiles
    const screenBounds = { x: -50, y: -50, width: CANVAS_WIDTH + 100, height: CANVAS_HEIGHT + 100 };
    state.playerProjectiles = state.playerProjectiles.filter(p => p.pos.x > screenBounds.x && p.pos.x < screenBounds.width && p.pos.y > screenBounds.y && p.pos.y < screenBounds.height);
    state.bossProjectiles = state.bossProjectiles.filter(p => p.pos.x > screenBounds.x && p.pos.x < screenBounds.width && p.pos.y > screenBounds.y && p.pos.y < screenBounds.height);
    
    // Update checksum
    state.checksum = calculateChecksum(state.score, state.level);

    // Check win/loss
    if (state.player.health <= 0) {
      onGameOver(state);
      return;
    }
    if (state.boss.health <= 0) {
      initLevel(state.level + 1, state);
    }

    // DRAWING LOGIC
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    
    // Screen shake
    if(state.screenShake > 0) {
        ctx.save();
        const dx = Math.random() * state.screenShake - state.screenShake / 2;
        const dy = Math.random() * state.screenShake - state.screenShake / 2;
        ctx.translate(dx, dy);
        state.screenShake *= 0.9;
    }
    
    // Draw collectibles
    state.collectibles.forEach(c => {
        ctx.drawImage(collectibleImage.current, c.pos.x - c.radius, c.pos.y - c.radius, c.radius * 2, c.radius * 2);
    });

    // Draw player
    ctx.drawImage(playerImage.current, state.player.pos.x - state.player.radius, state.player.pos.y - state.player.radius, state.player.radius * 2, state.player.radius * 2);

    // Draw boss
    ctx.fillStyle = `hsl(0, 100%, ${50 + (state.boss.health / state.boss.maxHealth) * 25}%)`;
    ctx.beginPath();
    ctx.arc(state.boss.pos.x, state.boss.pos.y, state.boss.radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = 'white';
    ctx.lineWidth = 3;
    ctx.stroke();

    // Draw player projectiles
    state.playerProjectiles.forEach(p => {
        ctx.drawImage(collectibleImage.current, p.pos.x - p.radius, p.pos.y - p.radius, p.radius * 2, p.radius * 2);
    });
    
    // Draw boss projectiles
    ctx.fillStyle = '#ff00ff';
    state.bossProjectiles.forEach(p => {
        ctx.beginPath();
        ctx.arc(p.pos.x, p.pos.y, p.radius, 0, Math.PI * 2);
        ctx.fill();
    });

    if(state.screenShake > 1) {
        ctx.restore();
    }
    
    onStateUpdate({...state});
    requestAnimationFrame(gameLoop);
  }, [gameStatus, onGameOver, onStateUpdate, initLevel]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const handleMouseMove = (e: MouseEvent) => {
      if (!gameState.current) return;
      const rect = canvas.getBoundingClientRect();
      gameState.current.mousePos.x = e.clientX - rect.left;
      gameState.current.mousePos.y = e.clientY - rect.top;
    };
    
    const handleMouseDown = (e: MouseEvent) => {
        if(e.button === 0) {
            initAudio(); // Initialize audio on first click
            if(gameState.current) gameState.current.isShooting = true;
        }
    };

    const handleMouseUp = (e: MouseEvent) => {
        if(e.button === 0 && gameState.current) gameState.current.isShooting = false;
    };
    
    const handleKeyDown = (e: KeyboardEvent) => {
        if(e.key === 'Escape') onPause();
    };

    canvas.addEventListener('mousemove', handleMouseMove);
    canvas.addEventListener('mousedown', handleMouseDown);
    canvas.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('keydown', handleKeyDown);

    lastTime.current = performance.now();
    const animationFrameId = requestAnimationFrame(gameLoop);

    return () => {
      cancelAnimationFrame(animationFrameId);
      canvas.removeEventListener('mousemove', handleMouseMove);
      canvas.removeEventListener('mousedown', handleMouseDown);
      canvas.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [gameLoop, onPause]);

  return <canvas ref={canvasRef} width={CANVAS_WIDTH} height={CANVAS_HEIGHT} className="bg-slate-800 shadow-2xl shadow-black" />;
};

export default GameCanvas;
