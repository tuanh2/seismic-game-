import React, { useState, useRef, useCallback, useEffect } from 'react';
import type { GameState } from '../types';
// FIX: Import LEVEL_CONFIGS to be used in win condition check.
import { PLAYER_IMAGE_B64, COLLECTIBLE_IMAGE_B64, LEVEL_CONFIGS } from '../constants';

interface GameOverScreenProps {
  finalState: GameState;
  onRestart: () => void;
}

const GameOverScreen: React.FC<GameOverScreenProps> = ({ finalState, onRestart }) => {
  const [name, setName] = useState('');
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [imagesLoaded, setImagesLoaded] = useState(false);
  const playerImage = useRef(new Image());
  const gemImage = useRef(new Image());

  useEffect(() => {
    let loadedCount = 0;
    const totalImages = 2;
    const onImageLoad = () => {
        loadedCount++;
        if (loadedCount === totalImages) {
            setImagesLoaded(true);
        }
    };
    playerImage.current.onload = onImageLoad;
    gemImage.current.onload = onImageLoad;
    playerImage.current.src = PLAYER_IMAGE_B64;
    gemImage.current.src = COLLECTIBLE_IMAGE_B64;
  }, []);

  const generateAndDownloadImage = useCallback(() => {
    if (!imagesLoaded) return;
    
    const canvas = document.createElement('canvas');
    canvas.width = 800;
    canvas.height = 450;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Background
    ctx.fillStyle = '#0f172a'; // bg-slate-900
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Title
    ctx.fillStyle = 'white';
    ctx.font = 'bold 48px monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = 'rgba(255,0,0,0.7)';
    ctx.shadowBlur = 15;
    ctx.fillText('SEISMIC SURVIVAL', canvas.width / 2, 60);
    ctx.shadowBlur = 0;

    // Player & Gem Images
    ctx.drawImage(playerImage.current, 50, 175, 100, 100);
    ctx.drawImage(gemImage.current, canvas.width - 150, 175, 100, 100);

    // Text content
    ctx.fillStyle = 'white';
    ctx.font = '24px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(`Pilot: ${name || 'Anonymous'}`, canvas.width / 2, 140);
    
    ctx.font = 'bold 36px monospace';
    ctx.fillStyle = '#ef4444'; // red-500
    const levelText = finalState.level > LEVEL_CONFIGS.length ? 'ALL CLEAR' : `Mag Cleared: ${finalState.level - 1}`;
    ctx.fillText(levelText, canvas.width / 2, 210);
    
    ctx.fillStyle = '#34d399'; // green-400
    ctx.font = 'bold 40px monospace';
    ctx.fillText(`Final Score: ${finalState.score}`, canvas.width / 2, 270);
    
    ctx.font = '16px monospace';
    ctx.fillStyle = 'gray';
    ctx.fillText(`Survived for ${Math.floor(finalState.gameTime / 1000)} seconds`, canvas.width / 2, 340);

    // Download link
    const link = document.createElement('a');
    link.download = `seismic_survival_${name.replace(/\s+/g, '_') || 'result'}.png`;
    link.href = canvas.toDataURL('image/png');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

  }, [name, finalState, imagesLoaded]);

  return (
    <div className="absolute inset-0 bg-black bg-opacity-85 flex flex-col items-center justify-center z-20 text-white text-center p-4">
      <h2 className="text-6xl md:text-8xl font-black text-red-600 mb-4 animate-pulse" style={{ textShadow: '0 0 10px #f00' }}>GAME OVER</h2>
      <p className="text-2xl md:text-3xl mb-2">Magnitude Reached: <span className="font-bold text-yellow-400">{finalState.level}</span></p>
      <p className="text-3xl md:text-4xl mb-6">Final Score: <span className="font-bold text-green-400">{finalState.score}</span></p>
      
      <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-2 mb-6">
        <input 
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value.slice(0, 20))}
          placeholder="Enter your name (DC/X)"
          className="bg-slate-700 border-2 border-slate-500 rounded-md px-4 py-2 text-xl text-center focus:outline-none focus:ring-2 focus:ring-red-500 w-full sm:w-auto"
        />
        <button
          onClick={generateAndDownloadImage}
          className="w-full sm:w-auto px-6 py-2 bg-blue-600 text-white font-bold text-xl rounded-md hover:bg-blue-700 transition-colors disabled:bg-gray-500 disabled:cursor-not-allowed"
          disabled={!name || !imagesLoaded}
          title={!imagesLoaded ? "Assets loading..." : !name ? "Enter a name to save" : "Save Summary Image"}
        >
          Save Summary
        </button>
      </div>

      <button
        onClick={onRestart}
        className="px-10 py-4 bg-yellow-500 text-black font-bold text-2xl rounded-lg hover:bg-yellow-600 transition-transform transform hover:scale-105"
      >
        Retry
      </button>
      <canvas ref={canvasRef} style={{ display: 'none' }} />
    </div>
  );
};

export default GameOverScreen;