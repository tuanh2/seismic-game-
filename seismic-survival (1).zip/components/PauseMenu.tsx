import React from 'react';

interface PauseMenuProps {
  onResume: () => void;
  onQuit: () => void;
}

const PauseMenu: React.FC<PauseMenuProps> = ({ onResume, onQuit }) => {
  return (
    <div className="absolute inset-0 bg-black bg-opacity-75 flex flex-col items-center justify-center z-20">
      <h2 className="text-7xl font-black text-white mb-8 animate-pulse" style={{ textShadow: '0 0 10px white' }}>PAUSED</h2>
      <div className="flex flex-col space-y-4">
        <button
          onClick={onResume}
          className="px-8 py-3 bg-green-500 text-white font-bold text-xl rounded-md hover:bg-green-600 transition-transform transform hover:scale-105"
        >
          Resume
        </button>
        <button
          onClick={onQuit}
          className="px-8 py-3 bg-red-600 text-white font-bold text-xl rounded-md hover:bg-red-700 transition-transform transform hover:scale-105"
        >
          Quit to Main Menu
        </button>
      </div>
    </div>
  );
};

export default PauseMenu;
