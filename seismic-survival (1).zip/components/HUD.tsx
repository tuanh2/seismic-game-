import React from 'react';
import type { GameState } from '../types';

interface HUDProps {
  gameState: GameState | null;
}

const HealthBar: React.FC<{ current: number; max: number; color: string }> = ({ current, max, color }) => {
    const percentage = Math.max(0, (current / max) * 100);
    return (
        <div className="w-full bg-gray-900 bg-opacity-50 rounded-full h-4 overflow-hidden border-2 border-gray-600">
            <div className={`${color} h-full rounded-full transition-all duration-200 ease-in-out`} style={{ width: `${percentage}%` }} />
        </div>
    );
};


const HUD: React.FC<HUDProps> = ({ gameState }) => {
  if (!gameState) {
    return null;
  }

  const { player, boss, score, level } = gameState;

  return (
    <div className="absolute top-0 left-0 w-full p-4 text-slate-100 font-mono z-10 pointer-events-none" style={{textShadow: '1px 1px 2px black'}}>
      <div className="flex justify-between items-start space-x-4">
        {/* Left Side: Player Info */}
        <div className="w-1/4">
          <h2 className="text-lg font-bold">GOLEM INTEGRITY</h2>
          <HealthBar current={player.health} max={player.maxHealth} color="bg-green-500" />
        </div>

        {/* Center: Score & Level */}
        <div className="text-center flex-shrink-0">
            <h2 className="text-4xl font-black tracking-widest">{`MAG ${level}`}</h2>
            <p className="text-2xl">{`SCORE: ${score.toString().padStart(8, '0')}`}</p>
        </div>

        {/* Right Side: Boss Info */}
        <div className="w-1/4">
           <h2 className="text-lg font-bold text-right">EPICENTER STABILITY</h2>
           <HealthBar current={boss.health} max={boss.maxHealth} color="bg-red-500" />
        </div>
      </div>
    </div>
  );
};

export default HUD;
