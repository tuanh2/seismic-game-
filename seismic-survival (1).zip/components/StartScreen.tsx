import React from 'react';

interface StartScreenProps {
  onStart: () => void;
}

const StartScreen: React.FC<StartScreenProps> = ({ onStart }) => {
  return (
    <div className="flex flex-col items-center justify-center text-center text-slate-50 p-4">
      <h1 className="text-6xl md:text-8xl font-black mb-4 uppercase tracking-widest" style={{ textShadow: '0 0 15px rgba(255, 0, 0, 0.7)' }}>
        Seismic Survival
      </h1>
      <p className="text-lg md:text-xl mb-8 max-w-2xl">
        Control the Golem with your mouse. Click to shoot. Collect Seismic Gems to increase your score. Survive the onslaught from the Epicenter.
      </p>
      <button
        onClick={onStart}
        className="px-10 py-4 bg-red-600 text-white font-bold text-2xl rounded-lg shadow-lg hover:bg-red-700 transition-transform transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-red-400"
      >
        BEGIN
      </button>
    </div>
  );
};

export default StartScreen;
