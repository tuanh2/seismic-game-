interface SoundMap {
  [key: string]: HTMLAudioElement;
}

const sounds: SoundMap = {};
let isAudioContextInitialized = false;

// Call this on the first user interaction
export const initAudio = () => {
    if (isAudioContextInitialized) return;
    try {
        // This dummy play call helps initialize the audio context on some browsers
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
        const buffer = audioContext.createBuffer(1, 1, 22050);
        const source = audioContext.createBufferSource();
        source.buffer = buffer;
        source.connect(audioContext.destination);
        source.start(0);
        isAudioContextInitialized = true;
        console.log("Audio context initialized.");
    } catch (e) {
        console.error("Could not initialize audio context:", e);
    }
};

export const loadSounds = (soundSources: { [key: string]: string }) => {
  Object.keys(soundSources).forEach(key => {
    if(!sounds[key]) {
        sounds[key] = new Audio(soundSources[key]);
    }
  });
};

export const playSound = (key: string, volume: number = 0.5) => {
  if (!isAudioContextInitialized) return;
  
  if (sounds[key]) {
    // Cloning the node allows for playing the same sound multiple times concurrently
    const sound = sounds[key].cloneNode() as HTMLAudioElement;
    sound.volume = volume;
    sound.play().catch(e => console.error(`Error playing sound "${key}":`, e));
  } else {
    console.warn(`Sound with key "${key}" not found.`);
  }
};
